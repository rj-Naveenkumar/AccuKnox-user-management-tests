# Problem Statement -2
  # 1. System Health Monitoring Script:

import psutil
import datetime

# Thresholds  - If usage of CPU, Memory, or Disk exceeds 80%, a warning will be logged.
CPU_THRESHOLD = 80
MEMORY_THRESHOLD = 80
DISK_THRESHOLD = 80

# Log file  -  log file where all issues will be written.
LOG_FILE = "system_health_log.txt"

#Adds the warning to the system_health_log.txt file with the timestamp.
def log_issue(message):
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(LOG_FILE, "a") as f:
        f.write(f"[{timestamp}] {message}\n")
    print(f" {message}")

def check_health():
    # CPU -Gets CPU usage in the last second.
    cpu = psutil.cpu_percent(interval=1)
    #If it's over 80%, logs it as a high CPU usage issue.
    if cpu > CPU_THRESHOLD:
        log_issue(f"High CPU usage: {cpu}%")

    # Memory   - ram usage
    memory = psutil.virtual_memory().percent
    if memory > MEMORY_THRESHOLD:
        log_issue(f"High Memory usage: {memory}%")

    # Disk - Checks how much of the root drive (/) is used.
    disk = psutil.disk_usage('/').percent
    if disk > DISK_THRESHOLD:
        log_issue(f"Low Disk space: {disk}% used")

    # Running Processes
    processes = len(psutil.pids())  # psutil.pids() - returns all running process IDs.
    print(f"System OK - CPU: {cpu}%, Memory: {memory}%, Disk: {disk}%, Processes: {processes}")

if __name__ == "__main__":
    check_health()
