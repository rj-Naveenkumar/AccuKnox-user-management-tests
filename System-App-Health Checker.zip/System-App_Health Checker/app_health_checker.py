# Problem Statement -2
  # 4. Application Health Checker:

import requests
import datetime

URL = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login"  #  app URL
LOG_FILE = "app_health_log.txt"   # status logs will be saved.

def log_app_status(status, code):
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(LOG_FILE, "a") as f:
        f.write(f"[{timestamp}] STATUS: {status} (HTTP {code})\n")
    print(f" App Status: {status} (Code: {code})")

def check_app():
    try:
        response = requests.get(URL, timeout=5)
        if response.status_code == 200:
            log_app_status("UP", response.status_code)
        else:
            log_app_status("DOWN", response.status_code)
    except requests.RequestException as e:
        log_app_status("DOWN", "No Response")
        print(f" Error: {e}")

if __name__ == "__main__":
    check_app()
